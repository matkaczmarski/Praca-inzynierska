GRIMM NIGHT
high res 1024^2 environment map
ships as TGA.


By Jockum Skoglund aka hipshot
hipshot@zfight.com
www.zfight.com
Stockholm, 2005 08 25


Modify however you like, just cred me for my work, maybe link to my page.

(Grimm is not a typo of Grim, some people understand the meaning)