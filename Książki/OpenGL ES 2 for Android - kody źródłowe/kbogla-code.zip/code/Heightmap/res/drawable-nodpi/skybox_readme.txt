THIS SKY WAS UPDATED AT THE 27TH
THE ORIG HAD SOME ERRORS

MIRAMAR
high res 1024^2 environment map
ships as TGA.


By Jockum Skoglund aka hipshot
hipshot@zfight.com
www.zfight.com
Stockholm, 2005 08 25


Modify however you like, just cred me for my work, maybe link to my page.
