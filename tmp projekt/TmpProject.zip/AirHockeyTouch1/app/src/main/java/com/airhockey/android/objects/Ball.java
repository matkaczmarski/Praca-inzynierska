package com.airhockey.android.objects;

/**
 * Created by Mateusz on 2014-12-03.
 */

        import java.util.List;

        import com.airhockey.android.data.VertexArray;
        import com.airhockey.android.objects.ObjectBuilder.DrawCommand;
        import com.airhockey.android.objects.ObjectBuilder.GeneratedData;
        import com.airhockey.android.programs.ColorShaderProgram;
        import com.airhockey.android.util.Geometry.Point;

public class Ball {
    private static final int POSITION_COMPONENT_COUNT = 3;

    public final float radius;

    private final VertexArray vertexArray;
    private final List<DrawCommand> drawList;

    public Ball(float radius, int numPointsAroundMallet) {

        GeneratedData generatedData = ObjectBuilder.createBall(new Point(0f, 0f, 0f), radius, numPointsAroundMallet);
        this.radius = radius;

        vertexArray = new VertexArray(generatedData.vertexData);
        drawList = generatedData.drawList;
    }

    public void bindData(ColorShaderProgram colorProgram) {
        vertexArray.setVertexAttribPointer(0,
                colorProgram.getPositionAttributeLocation(),
                POSITION_COMPONENT_COUNT, 0);
    }

    public void draw() {
        for (DrawCommand drawCommand : drawList) {
            drawCommand.draw();
        }
    }
}
